# Safe Vision Dashboard

Prototype dashboard for Saudi Red Crescent with Computer Vision incident analytics.