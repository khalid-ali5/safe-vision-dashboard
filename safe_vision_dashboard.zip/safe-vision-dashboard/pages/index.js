// Main Safe Vision Dashboard UI will go here
export { default } from '../src/SafeVisionDashboard';
